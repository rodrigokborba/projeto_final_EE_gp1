var searchData=
[
  ['controlchoose_0',['controlchoose',['../main_8c.html#ad28f2fbffd94b946dc303212b3b4ec0d',1,'controlchoose():&#160;main.c'],['../main_8h.html#ad28f2fbffd94b946dc303212b3b4ec0d',1,'controlchoose():&#160;main.c']]]
];
