var searchData=
[
  ['balldist_0',['balldist',['../main_8h.html#aaedc210236e3701dc07523185f991dfd',1,'main.h']]],
  ['ballset_1',['ballset',['../main_8h.html#ad9617048781a1b74a4778faf41d43994',1,'main.h']]],
  ['buffer_5fmax_2',['BUFFER_MAX',['../main_8h.html#a65c660282414eff7e990f21f6b306cb8',1,'main.h']]],
  ['bufferrx_3',['bufferRx',['../main_8h.html#a1de5c8389ea43f40f8c9f015fc55aef1',1,'main.h']]]
];
