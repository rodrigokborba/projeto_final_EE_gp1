var searchData=
[
  ['v_0',['v',['../main_8h.html#ac5f38113a34f9eab3e7782eade81d266',1,'main.h']]],
  ['vh_1',['vH',['../main_8h.html#a41278e804db61fa3f1897c9ef5782b8d',1,'main.h']]],
  ['vl_2',['vL',['../main_8h.html#a33d51b34cd3e8bde75d2afd55f9c4198',1,'main.h']]],
  ['vrx_3',['vRx',['../main_8h.html#a19e0173ab1f14f65121f8d9e66fc37c9',1,'main.h']]],
  ['vtx_4',['vTx',['../main_8h.html#a860fff85809bcddbb430c4410e8bb81e',1,'main.h']]]
];
