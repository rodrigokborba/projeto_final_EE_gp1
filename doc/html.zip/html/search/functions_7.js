var searchData=
[
  ['setaporta_0',['setaPorta',['../main_8c.html#a054b243e304b4f64ce53ade62f2d6d14',1,'setaPorta():&#160;main.c'],['../main_8h.html#a054b243e304b4f64ce53ade62f2d6d14',1,'setaPorta():&#160;main.c']]]
];
