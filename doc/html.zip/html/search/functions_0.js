var searchData=
[
  ['analisa_5frx_0',['analisa_Rx',['../main_8c.html#abe26cbff6b6464eaec07aef4fab20903',1,'analisa_Rx():&#160;main.c'],['../main_8h.html#abe26cbff6b6464eaec07aef4fab20903',1,'analisa_Rx():&#160;main.c']]]
];
