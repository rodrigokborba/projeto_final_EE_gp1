var searchData=
[
  ['horario_0',['HORARIO',['../main_8h.html#ad201cbebd7013a4e8dcc53c9aaed6734',1,'main.h']]]
];
