var searchData=
[
  ['sentido_0',['sentido',['../main_8h.html#abc6943ffb4d0761e7242fd1c34af955b',1,'main.h']]],
  ['setaporta_1',['setaPorta',['../main_8c.html#a054b243e304b4f64ce53ade62f2d6d14',1,'setaPorta():&#160;main.c'],['../main_8h.html#a054b243e304b4f64ce53ade62f2d6d14',1,'setaPorta():&#160;main.c']]],
  ['sp_5fheight_2',['sp_height',['../main_8h.html#a36176de459d649122236d20595bc05e6',1,'main.h']]],
  ['sp_5fposition_3',['sp_position',['../main_8h.html#a3af209467eb98a1e4b5549f4469fa169',1,'main.h']]]
];
