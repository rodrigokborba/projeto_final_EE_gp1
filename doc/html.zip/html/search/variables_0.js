var searchData=
[
  ['adc_5ftemp_0',['adc_temp',['../main_8h.html#a6d9d9c71eca0c1af12b4cd377a4693ab',1,'main.h']]],
  ['avg_5ftempo_5fvoo_1',['avg_tempo_voo',['../main_8h.html#a222dc612293b75bba87bfe23746aaff6',1,'main.h']]]
];
