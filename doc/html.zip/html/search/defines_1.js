var searchData=
[
  ['buffer_5fmax_0',['BUFFER_MAX',['../main_8h.html#a65c660282414eff7e990f21f6b306cb8',1,'main.h']]]
];
