var searchData=
[
  ['envia_5ftx_0',['envia_Tx',['../main_8c.html#a904b71ef009cd608eef4c03f3b86570e',1,'envia_Tx():&#160;main.c'],['../main_8h.html#a904b71ef009cd608eef4c03f3b86570e',1,'envia_Tx():&#160;main.c']]],
  ['error_1',['error',['../main_8h.html#a29e02f629673f5321791cbe4afc7cfac',1,'main.h']]],
  ['errorp_2',['errorp',['../main_8h.html#a12c88fea0b1f492551773a9b46d946fd',1,'main.h']]]
];
