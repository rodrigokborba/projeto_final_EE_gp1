var searchData=
[
  ['fluxcontrol_0',['fluxcontrol',['../main_8c.html#a926d0536e9a967aabbdc93ec26f133fe',1,'fluxcontrol():&#160;main.c'],['../main_8h.html#a926d0536e9a967aabbdc93ec26f133fe',1,'fluxcontrol():&#160;main.c']]],
  ['fluxpos_1',['fluxpos',['../main_8c.html#a06f373833c78e3d19c62de24014b173f',1,'fluxpos():&#160;main.c'],['../main_8h.html#a06f373833c78e3d19c62de24014b173f',1,'fluxpos():&#160;main.c']]]
];
