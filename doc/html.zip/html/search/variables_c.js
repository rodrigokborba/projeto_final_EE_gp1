var searchData=
[
  ['sentido_0',['sentido',['../main_8h.html#abc6943ffb4d0761e7242fd1c34af955b',1,'main.h']]],
  ['sp_5fheight_1',['sp_height',['../main_8h.html#a36176de459d649122236d20595bc05e6',1,'main.h']]],
  ['sp_5fposition_2',['sp_position',['../main_8h.html#a3af209467eb98a1e4b5549f4469fa169',1,'main.h']]]
];
