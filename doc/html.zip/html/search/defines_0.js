var searchData=
[
  ['antihorario_0',['ANTIHORARIO',['../main_8h.html#ade08810c4d344187b531dfd7d2764448',1,'main.h']]]
];
