var searchData=
[
  ['passo_0',['passo',['../main_8h.html#ae92353ba4733549c916df0ffc6a87abf',1,'main.h']]],
  ['passo_5fctrl_1',['passo_ctrl',['../main_8h.html#a1925f7a6321b39d331e3c1c3a9c26fa3',1,'main.h']]],
  ['position_2',['position',['../main_8h.html#a6f14bde43ef12199f2d2ef07adb6c942',1,'main.h']]]
];
