var searchData=
[
  ['nao_5fsalva_0',['nao_salva',['../main_8h.html#a20e77aa13b3a08ff093a1c92a0104609',1,'main.h']]]
];
