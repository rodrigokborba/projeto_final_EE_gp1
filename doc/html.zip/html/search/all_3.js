var searchData=
[
  ['daumpasso_0',['daUmPasso',['../main_8c.html#a0472d58924340cad53890fd9253f3c8e',1,'daUmPasso(uint8_t sentido):&#160;main.c'],['../main_8h.html#a0472d58924340cad53890fd9253f3c8e',1,'daUmPasso(uint8_t sentido):&#160;main.c']]],
  ['dc_1',['dc',['../main_8h.html#adb07fc3f35b1ac3f277f3c4b80ce2269',1,'main.h']]],
  ['definepassomotor_2',['definePassoMotor',['../main_8c.html#a131af577797d8952102f708fa2521f5e',1,'definePassoMotor(uint8_t passom, uint8_t sentido):&#160;main.c'],['../main_8h.html#a131af577797d8952102f708fa2521f5e',1,'definePassoMotor(uint8_t passom, uint8_t sentido):&#160;main.c']]],
  ['dinput_3',['dinput',['../main_8h.html#ada05941062f2bf29de9cd731ae4aedad',1,'main.h']]]
];
