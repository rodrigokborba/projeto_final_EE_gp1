var searchData=
[
  ['fim_5fcurso_0',['fim_curso',['../main_8h.html#a715651318d39fb1c14ba9c4f439e5ee6',1,'main.h']]],
  ['first_5fread_1',['first_read',['../main_8h.html#a99c6f38e3102517e3a6b83909624e0f1',1,'main.h']]],
  ['flux_2',['flux',['../main_8h.html#ac7a2de020474d9c2ebfdcccd35bbbc5a',1,'main.h']]],
  ['fluxcontrol_3',['fluxcontrol',['../main_8c.html#a926d0536e9a967aabbdc93ec26f133fe',1,'fluxcontrol():&#160;main.c'],['../main_8h.html#a926d0536e9a967aabbdc93ec26f133fe',1,'fluxcontrol():&#160;main.c']]],
  ['fluxpos_4',['fluxpos',['../main_8c.html#a06f373833c78e3d19c62de24014b173f',1,'fluxpos():&#160;main.c'],['../main_8h.html#a06f373833c78e3d19c62de24014b173f',1,'fluxpos():&#160;main.c']]],
  ['func_5fmode_5',['func_mode',['../main_8h.html#a01a73e571fab8f8955e6370c989ec854',1,'main.h']]]
];
