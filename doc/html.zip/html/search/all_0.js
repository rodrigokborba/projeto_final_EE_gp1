var searchData=
[
  ['adc_5ftemp_0',['adc_temp',['../main_8h.html#a6d9d9c71eca0c1af12b4cd377a4693ab',1,'main.h']]],
  ['analisa_5frx_1',['analisa_Rx',['../main_8c.html#abe26cbff6b6464eaec07aef4fab20903',1,'analisa_Rx():&#160;main.c'],['../main_8h.html#abe26cbff6b6464eaec07aef4fab20903',1,'analisa_Rx():&#160;main.c']]],
  ['antihorario_2',['ANTIHORARIO',['../main_8h.html#ade08810c4d344187b531dfd7d2764448',1,'main.h']]],
  ['avg_5ftempo_5fvoo_3',['avg_tempo_voo',['../main_8h.html#a222dc612293b75bba87bfe23746aaff6',1,'main.h']]]
];
