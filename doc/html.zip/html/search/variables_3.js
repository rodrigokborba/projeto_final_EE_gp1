var searchData=
[
  ['dc_0',['dc',['../main_8h.html#adb07fc3f35b1ac3f277f3c4b80ce2269',1,'main.h']]],
  ['dinput_1',['dinput',['../main_8h.html#ada05941062f2bf29de9cd731ae4aedad',1,'main.h']]]
];
