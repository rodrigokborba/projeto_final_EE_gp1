var searchData=
[
  ['outpre_0',['outpre',['../main_8h.html#aa2955844c10768c2d30386af1c294eda',1,'main.h']]],
  ['output_1',['output',['../main_8h.html#a00505972efb8c1749fb3f62c490314a2',1,'main.h']]],
  ['outputsum_2',['outputsum',['../main_8h.html#a602a2450a9d4c5408392ae82aa82497d',1,'main.h']]]
];
