var searchData=
[
  ['envia_5ftx_0',['envia_Tx',['../main_8c.html#a904b71ef009cd608eef4c03f3b86570e',1,'envia_Tx():&#160;main.c'],['../main_8h.html#a904b71ef009cd608eef4c03f3b86570e',1,'envia_Tx():&#160;main.c']]]
];
