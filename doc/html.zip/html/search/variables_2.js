var searchData=
[
  ['controlchoice_0',['controlchoice',['../main_8h.html#a9c104204852b921a34d47805e02a67f7',1,'main.h']]],
  ['count_5ftx_1',['count_Tx',['../main_8h.html#a68d6036d0fcff4ed331c5424f1dd09b1',1,'main.h']]],
  ['countrx_2',['countRx',['../main_8h.html#a052035fde037a49cfc6cd6dc09e6deea',1,'main.h']]]
];
