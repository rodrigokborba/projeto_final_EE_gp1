var searchData=
[
  ['tempo_5fvoo_0',['tempo_voo',['../main_8h.html#afd3aa9032b7881ddcfa92b703b8ffce1',1,'main.h']]],
  ['timecontrol_1',['timecontrol',['../main_8h.html#a1c6a810388d5cb406a75d405dc4d7fe6',1,'main.h']]]
];
