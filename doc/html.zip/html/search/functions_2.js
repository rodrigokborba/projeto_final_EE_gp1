var searchData=
[
  ['daumpasso_0',['daUmPasso',['../main_8c.html#a0472d58924340cad53890fd9253f3c8e',1,'daUmPasso(uint8_t sentido):&#160;main.c'],['../main_8h.html#a0472d58924340cad53890fd9253f3c8e',1,'daUmPasso(uint8_t sentido):&#160;main.c']]],
  ['definepassomotor_1',['definePassoMotor',['../main_8c.html#a131af577797d8952102f708fa2521f5e',1,'definePassoMotor(uint8_t passom, uint8_t sentido):&#160;main.c'],['../main_8h.html#a131af577797d8952102f708fa2521f5e',1,'definePassoMotor(uint8_t passom, uint8_t sentido):&#160;main.c']]]
];
