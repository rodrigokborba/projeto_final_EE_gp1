var searchData=
[
  ['controlchoice_0',['controlchoice',['../main_8h.html#a9c104204852b921a34d47805e02a67f7',1,'main.h']]],
  ['controlchoose_1',['controlchoose',['../main_8c.html#ad28f2fbffd94b946dc303212b3b4ec0d',1,'controlchoose():&#160;main.c'],['../main_8h.html#ad28f2fbffd94b946dc303212b3b4ec0d',1,'controlchoose():&#160;main.c']]],
  ['count_5ftx_2',['count_Tx',['../main_8h.html#a68d6036d0fcff4ed331c5424f1dd09b1',1,'main.h']]],
  ['countrx_3',['countRx',['../main_8h.html#a052035fde037a49cfc6cd6dc09e6deea',1,'main.h']]]
];
